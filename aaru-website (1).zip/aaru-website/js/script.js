/* ================================================================
   AARU GREEN HYDROGEN — MAIN SCRIPT
   Sections: Three.js particle background, nav scroll/progress,
   active nav link tracking, scroll-reveal animations,
   modal (with focus trap), contact form (validation + submission).
   ================================================================ */


  // ── THREE.JS PARTICLE BACKGROUND ──
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  const renderer = new THREE.WebGLRenderer({ canvas: document.getElementById('bg-canvas'), alpha: true, antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  camera.position.z = 30;

  const count = 1800;
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(count * 3);
  const sizes = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    pos[i*3]   = (Math.random() - 0.5) * 140;
    pos[i*3+1] = (Math.random() - 0.5) * 90;
    pos[i*3+2] = (Math.random() - 0.5) * 70 - 20;
    sizes[i] = Math.random();
  }
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const mat = new THREE.PointsMaterial({
    color: 0x6fa845, size: 0.1, transparent: true, opacity: 0.22, sizeAttenuation: true
  });
  const particles = new THREE.Points(geo, mat);
  scene.add(particles);

  let t = 0;
  let animationPaused = false;
  (function animate() {
    requestAnimationFrame(animate);
    if (animationPaused) return;
    t += 0.001;
    particles.rotation.y = t * 0.04;
    particles.rotation.x = Math.sin(t * 0.02) * 0.015;
    renderer.render(scene, camera);
  })();

  document.addEventListener('visibilitychange', () => {
    animationPaused = document.hidden;
  });

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // ── NAV SCROLL, PROGRESS BAR, BACK-TO-TOP ──
  const scrollProgress = document.getElementById('scrollProgress');
  const backToTop = document.getElementById('backToTop');
  window.addEventListener('scroll', () => {
    document.getElementById('mainNav').classList.toggle('scrolled', window.scrollY > 40);
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docHeight > 0 ? (window.scrollY / docHeight) * 100 : 0;
    scrollProgress.style.width = pct + '%';
    backToTop.classList.toggle('visible', window.scrollY > 500);
  }, { passive: true });

  // ── ACTIVE NAV LINK ON SCROLL ──
  const navSections = Array.from(document.querySelectorAll('section[id]'));
  const navLinkMap = {};
  document.querySelectorAll('.nav-links a[href^="#"]').forEach(a => {
    navLinkMap[a.getAttribute('href').slice(1)] = a;
  });
  const navActiveObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      const link = navLinkMap[e.target.id];
      if (!link) return;
      if (e.isIntersecting) {
        Object.values(navLinkMap).forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      }
    });
  }, { threshold: 0, rootMargin: '-45% 0px -50% 0px' });
  navSections.forEach(s => navActiveObserver.observe(s));

  // ── SCROLL REVEAL ──
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); } });
  }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });
  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

  // ── TECH BAR ANIMATION ──
  const barObserver = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.querySelectorAll('.tech-bar-fill').forEach(bar => {
          bar.style.width = bar.dataset.width + '%';
        });
      }
    });
  }, { threshold: 0.3 });
  document.querySelectorAll('.tech-grid').forEach(el => barObserver.observe(el));

  // ── MODAL (with focus trap + return focus) ──
  let lastFocusedBeforeModal = null;
  function getFocusableInModal() {
    return Array.from(document.getElementById('modalBox')
      .querySelectorAll('a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])'));
  }
  function trapModalFocus(e) {
    if (e.key !== 'Tab') return;
    const focusable = getFocusableInModal();
    if (!focusable.length) return;
    const first = focusable[0], last = focusable[focusable.length - 1];
    if (e.shiftKey && document.activeElement === first) {
      e.preventDefault(); last.focus();
    } else if (!e.shiftKey && document.activeElement === last) {
      e.preventDefault(); first.focus();
    }
  }
  function openModal() {
    lastFocusedBeforeModal = document.activeElement;
    document.getElementById('modalBackdrop').classList.add('open');
    document.getElementById('modalBox').classList.add('open');
    document.body.style.overflow = 'hidden';
    const focusable = getFocusableInModal();
    if (focusable.length) focusable[0].focus();
    document.addEventListener('keydown', trapModalFocus);
  }
  function closeModal() {
    document.getElementById('modalBackdrop').classList.remove('open');
    document.getElementById('modalBox').classList.remove('open');
    document.body.style.overflow = '';
    document.removeEventListener('keydown', trapModalFocus);
    if (lastFocusedBeforeModal) lastFocusedBeforeModal.focus();
  }
  function handleBackdropClick(e) {
    if (e.target === document.getElementById('modalBackdrop')) closeModal();
  }
  window.openModal = openModal;
  window.closeModal = closeModal;
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

  // ── CONTACT FORM ──
  // ── CONTACT FORM: validation + real submission ──
  const contactForm = document.getElementById('contactForm');
  const fields = {
    userName:   { group: 'group-userName',   validate: v => v.trim().length > 0 },
    userEmail:  { group: 'group-userEmail',  validate: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim()) },
    subject:    { group: 'group-subject',    validate: v => v.trim().length > 0 },
    message:    { group: 'group-message',    validate: v => v.trim().length >= 10 }
  };

  function validateField(id) {
    const el = document.getElementById(id);
    const cfg = fields[id];
    const group = document.getElementById(cfg.group);
    const ok = cfg.validate(el.value);
    group.classList.toggle('has-error', !ok);
    group.classList.toggle('is-valid', ok);
    return ok;
  }

  Object.keys(fields).forEach(id => {
    const el = document.getElementById(id);
    el.addEventListener('blur', () => validateField(id));
    el.addEventListener('input', () => {
      const group = document.getElementById(fields[id].group);
      if (group.classList.contains('has-error')) validateField(id);
    });
  });

  contactForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = document.getElementById('submitBtn');
    const status = document.getElementById('formStatus');
    const label = btn.querySelector('.form-submit-label');

    // Honeypot spam check
    if (document.querySelector('[name="_honey"]').value) return;

    let allValid = true;
    Object.keys(fields).forEach(id => { if (!validateField(id)) allValid = false; });
    if (!allValid) {
      status.innerHTML = '<span style="color:#c0392b;">Please fix the highlighted fields.</span>';
      return;
    }

    btn.disabled = true; btn.classList.add('loading'); label.textContent = 'Sending…';
    status.innerHTML = '';

    const payload = {
      name: document.getElementById('userName').value.trim(),
      email: document.getElementById('userEmail').value.trim(),
      company: document.getElementById('userCompany').value.trim(),
      inquiry_type: document.getElementById('subject').value,
      message: document.getElementById('message').value.trim(),
      _subject: 'New inquiry — Aaru Green Hydrogen website'
    };

    fetch('https://formsubmit.co/ajax/aarugreenhydrogen@gmail.com', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(payload)
    })
      .then(res => {
        if (!res.ok) throw new Error('Network response was not ok: ' + res.status);
        return res.json();
      })
      .then(data => {
        console.log('FormSubmit response:', data);
        status.innerHTML = '<span style="color:#2c7a2c; background:#e6f4e6; padding:8px 20px; border-radius:100px; font-size:13px;">✓ Request received — if this is the first-ever submission, check aarugreenhydrogen@gmail.com (incl. spam) for a one-time activation email from FormSubmit.</span>';
        contactForm.reset();
        Object.keys(fields).forEach(id => {
          document.getElementById(fields[id].group).classList.remove('is-valid', 'has-error');
        });
        setTimeout(() => status.innerHTML = '', 10000);
      })
      .catch(err => {
        console.error('Form submission failed:', err);
        status.innerHTML = '<span style="color:#c0392b;">Something went wrong — please email us directly at aarugreenhydrogen@gmail.com.</span>';
      })
      .finally(() => {
        btn.disabled = false; btn.classList.remove('loading'); label.textContent = 'Send Inquiry →';
      });
  });
